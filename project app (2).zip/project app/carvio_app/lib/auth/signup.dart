import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final restaurantController = TextEditingController();
  final locationController = TextEditingController();
  final pincodeController = TextEditingController();

  String role = 'user'; // user | admin
  bool loading = false;

  static const String signupUrl =
      'https://cravio-xy2a.onrender.com/api/auth/signup';

  Future<void> signup() async {
    FocusScope.of(context).unfocus();
    setState(() => loading = true);

    final Map<String, dynamic> body = {
      'name': nameController.text.trim(),
      'phone': phoneController.text.trim(),
      'password': passwordController.text.trim(),
      'role': role,
    };

    if (role == 'admin') {
      body.addAll({
        'restaurantName': restaurantController.text.trim(),
        'location': locationController.text.trim(),
        'pincode': pincodeController.text.trim(),
      });
    }

    final response = await http.post(
      Uri.parse(signupUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );

    setState(() => loading = false);

    if (response.statusCode == 200 || response.statusCode == 201) {
      Navigator.pop(context); // back to login
    } else {
      final msg = jsonDecode(response.body)['message'] ?? 'Signup failed';
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FA),
      appBar: AppBar(
        title: const Text('Create Account'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              _inputField('Name', nameController),
              _inputField('Phone number', phoneController,
                  keyboardType: TextInputType.phone),
              _inputField('Password', passwordController, isPassword: true),

              const SizedBox(height: 12),

              ToggleButtons(
                borderRadius: BorderRadius.circular(16),
                isSelected: [role == 'user', role == 'admin'],
                onPressed: (index) {
                  setState(() {
                    role = index == 0 ? 'user' : 'admin';
                  });
                },
                children: const [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Text('User'),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24),
                    child: Text('Restaurant'),
                  ),
                ],
              ),

              if (role == 'admin') ...[
                const SizedBox(height: 20),
                _inputField('Restaurant name', restaurantController),
                _inputField('Location', locationController),
                _inputField('Pincode', pincodeController,
                    keyboardType: TextInputType.number),
              ],

              const SizedBox(height: 30),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: loading ? null : signup,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: loading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Create Account',
                          style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _inputField(
    String hint,
    TextEditingController controller, {
    bool isPassword = false,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: const Color(0xFFF1F2F4),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }
}
